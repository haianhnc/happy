import React, { Component } from 'react';

class OneTag extends Component {
  render(){
    let tag = this.props.tag;
    return(
      <div className="OneTag">
        {tag}
      </div>
      );
  }
}

export default OneTag;