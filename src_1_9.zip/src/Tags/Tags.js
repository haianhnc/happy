import React, { Component } from 'react';

import OneTag from "./OneTag"

class Tags extends Component {
  render(){
    let title = this.props.tags.title;
    let tags = this.props.tags.tags;
    let data_lists = [];

    tags.forEach(function(unit){
      data_lists.push(<OneTag tag={unit} />);
    });
    return(
      <div className="Tags">
        <div className="title"><h1>{title}</h1></div>
        <div className="content">
          {data_lists}
        </div>
      </div>
    );
  }
}

export default Tags;