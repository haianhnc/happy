import React, { Component } from 'react';

import star_icon from '../images/star.png'

class Starbar extends Component{
  render(){
    let star_num = this.props.star;
    let star_arr = [];
    for(let i=0; i< star_num; i++){
      star_arr.push(<div className="star_icon"><img src={star_icon} height="10" width="10" /></div>);
    }

    return(
        <div className="star_bar">{star_arr}</div>
      );
  }
}

export default Starbar;