import React, { Component } from 'react';

import Starbar from './Starbar'
import ShowMoreButton from './ShowMoreButton'

import left_icon from '../images/left.png'
import right_icon from '../images/right.png'

class TodayContestRanking extends Component {
  render(){
    let title = this.props.contest.title;
    let today = new Date();
    let user_name = this.props.contest.name;
    let star = this.props.contest.star;
    // let left_icon = this.props.contest.left_icon;
    // let right_icon = this.props.contest.right_icon;
    let contest = this.props.contest.content;

    return(
        <div className="contest">
          <div className="ranking">
            <div className="img_left"><img src={left_icon} height="50" width="50" /></div>
            
            <div className="contest_body">
              <h1 className="title"> { title }</h1>
              <div className="ranking_date"><div>{today.toLocaleDateString("en-US")}</div></div>
              <div className="contest_user">{user_name}</div>
               <Starbar star={star}/>
            </div>

            <div className="img_right"><img src={right_icon} height="50" width="50" /></div>
          </div>
          <div className="rankingContent">
            {contest}
          </div>
          <ShowMoreButton more="more >>>"/>
        </div>
      );
  }
}

export default TodayContestRanking;