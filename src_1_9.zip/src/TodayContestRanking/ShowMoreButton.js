import React, { Component } from 'react';

class ShowMoreButton extends Component{
  render(){
    const more = this.props.more;
    return(
        <div className="ShowMoreButton"><a href="#">{more}</a></div>
      );
  }
}

export default ShowMoreButton;