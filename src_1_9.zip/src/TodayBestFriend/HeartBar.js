import React, { Component } from 'react';

import heart_icon from '../images/heart.png'

class HeartBar extends Component{
  render(){
    let heart_num = this.props.heart;
    let heart_arr = [];
    for(let i=0; i< heart_num; i++){
      heart_arr.push(<div className="heart_icon"><img src={heart_icon} height="16" width="16" /></div>);
    }

    return(
        <div className="heart_bar">{heart_arr}</div>
      );
  }
}

export default HeartBar;