import React, { Component } from 'react';

class GotoLineButton extends Component{
  render(){
    const more = this.props.more;
    return(
        <div className="GotoLineButton"><a href="#">{more}</a></div>
      );
  }
}

export default GotoLineButton;