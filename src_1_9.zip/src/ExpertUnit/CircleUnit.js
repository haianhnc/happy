import React, { Component } from 'react';

class CircleUnit extends Component {
  render(){
    let image = this.props.circle_unit.icon;
    let text = this.props.circle_unit.content;
    return(
      <div className="CircleUnit">
        <div className="circle_unit_img"><img src={image} height="25" width="40" /></div>
        <div className="text">{text}</div>
      </div>
    );
  }
}

export default CircleUnit;