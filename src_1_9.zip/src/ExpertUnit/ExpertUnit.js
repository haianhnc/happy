import React, { Component } from 'react';

import CircleUnit from "./CircleUnit";

class ExpertUnit extends Component {
  render(){
    let title = this.props.experts.title;
    let cicler_units = this.props.experts.cicler_units;
    let data_lists = [];

    cicler_units.forEach(function(unit){
      data_lists.push(<CircleUnit circle_unit={unit} />);
    });

  return(
    <div className="ExpertUnit">
      <div className="title"><h1>{title}</h1></div>
      <div className="content">
        {data_lists}
      </div>
    </div>
  );
  }
}

export default ExpertUnit;