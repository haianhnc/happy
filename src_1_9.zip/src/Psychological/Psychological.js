import React, { Component } from 'react';

import HolizoUnit from "./HolizoUnit"

class Psychological extends Component {
  render(){
    let holizo_units = this.props.psychological.holizo_units;
    let title = this.props.psychological.title;
    let data_lists = [];

    holizo_units.forEach(function(unit){
      data_lists.push(<HolizoUnit holizo_unit={unit} />);
    });

    return(
        <div className="Psychological">
          <div className="title"><h1>{title}</h1></div>
          <div className="content">
            {data_lists}
          </div>
        </div>
    );
  }
}

export default Psychological;