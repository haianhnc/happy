import React, { Component } from 'react';

import horizon from '../images/horizon.jpg'

class HolizoUnit extends Component {
  render(){
    let image = this.props.holizo_unit.icon;
    let text = this.props.holizo_unit.content;
    return(
      <div className="HolizoUnit">
        <div className="HolizoUnitImage"><img src={horizon} height="25" width="40" /></div>
        <div className="text">{text}</div>
      </div>
      );
  }
}

export default HolizoUnit;