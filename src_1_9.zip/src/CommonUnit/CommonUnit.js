import React, { Component } from 'react';
import VerticalUnit from './VerticalUnit'

class CommonUnit extends Component {
  render(){
    let title = this.props.common.title;
    let vertical_units = this.props.common.vertical_units
    let data_lists = [];

    vertical_units.forEach(function(unit){
      data_lists.push(<VerticalUnit verticalunit={unit} />);
    });

    return(
        <div className="CommonUnit">
          <div className="title"><h1>{title}</h1></div>
          <div className="content">
            {data_lists}
          </div>
        </div>
      );
  }
}

export default CommonUnit;