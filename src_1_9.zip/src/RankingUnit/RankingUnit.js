import React, { Component } from 'react';

import RankRow from "./RankRow"
class RankingUnit extends Component {
  render(){
    let title = this.props.rankingunit.title;
    let rank_rows = this.props.rankingunit.rank_rows;
    let data_lists = [];

    rank_rows.forEach(function(row){
      data_lists.push(<RankRow rankrow={row} />);
    });

    return(
        <div className="RankingUnit">
          <div className="title"><h1>{title}</h1></div>
          <div className="rank_rows">
            {data_lists}
          </div>
        </div>
      );
  }
}

export default RankingUnit;