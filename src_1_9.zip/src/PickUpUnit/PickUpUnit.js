import React, { Component } from 'react';

import FirstFeatureBanner from './FirstFeatureBanner';
import HorizontalUnit from './HorizontalUnit';


class PickUpUnit extends Component {
  render(){
    let title = this.props.pickupunit.title;
    let first_feature_banner = this.props.pickupunit.first_feature_banner;
    let data_rows = this.props.pickupunit.data;
    let data_lists = [];
    let row;

    data_rows.forEach(function(row){
      data_lists.push(<HorizontalUnit horizontal_unit={row} />);
    });

    return(
      <div className="PickUpUnit">
        <div className="title"><h1>{title}</h1></div>
        <FirstFeatureBanner first_feature_banner={first_feature_banner} />
        <div>{data_lists}</div>
      </div>
    );
  }
}

export default PickUpUnit;